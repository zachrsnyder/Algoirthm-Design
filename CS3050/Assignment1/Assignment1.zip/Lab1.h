#include<stdlib.h>
#include<stdio.h>
#include<limits.h>
#include<time.h>
#include<math.h>

int obtainRandomSample(int *sequence); // INT_MAX terminated

int testRandomSample(); // You’ll need to provide your test file
